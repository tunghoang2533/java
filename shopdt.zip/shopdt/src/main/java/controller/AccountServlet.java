package controller;

import dao.AccountDAO;
import model.Account;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/AccountServlet")
public class AccountServlet extends HttpServlet {
    private AccountDAO dao;

    @Override
    public void init() throws ServletException {
        dao = new AccountDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if(action==null) action="list";
        switch(action){
            case "list":
                List<Account> list = dao.getAll();
                request.setAttribute("accounts", list);
                request.getRequestDispatcher("/account/list.jsp").forward(request,response);
                break;
            case "form":
                request.getRequestDispatcher("/account/form.jsp").forward(request,response);
                break;
            case "edit":
                int id = Integer.parseInt(request.getParameter("id"));
                Account a = dao.getById(id);
                request.setAttribute("account", a);
                request.getRequestDispatcher("/account/edit.jsp").forward(request,response);
                break;
            case "delete":
                int did = Integer.parseInt(request.getParameter("id"));
                dao.delete(did);
                response.sendRedirect("AccountServlet?action=list");
                break;
            default:
                response.sendRedirect("AccountServlet?action=list");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String idStr = request.getParameter("id");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String fullname = request.getParameter("fullname");
        String role = request.getParameter("role");
        int status = request.getParameter("status")!=null?1:0;

        if(idStr==null || idStr.isEmpty()){
            Account a = new Account();
            a.setUsername(username); a.setPassword(password); a.setFullname(fullname); a.setRole(role); a.setStatus(status);
            dao.insert(a);
        } else {
            int id = Integer.parseInt(idStr);
            Account a = new Account();
            a.setId(id); a.setUsername(username); a.setPassword(password); a.setFullname(fullname); a.setRole(role); a.setStatus(status);
            dao.update(a);
        }
        response.sendRedirect("AccountServlet?action=list");
    }
}
