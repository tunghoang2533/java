package controller;

import dao.HoadonDAO;
import model.Hoadon;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@WebServlet("/HoadonServlet")
public class HoadonServlet extends HttpServlet {

    private HoadonDAO dao;

    @Override
    public void init() {
        dao = new HoadonDAO();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        if (action == null) action = "list";

        switch (action) {

            case "form":  // thêm
                req.getRequestDispatcher("hoadon/form.jsp").forward(req, resp);
                break;

            case "edit":  // sửa
                int id = Integer.parseInt(req.getParameter("id"));
                Hoadon h = dao.getById(id);
                req.setAttribute("hoadon", h);
                req.getRequestDispatcher("hoadon/edit.jsp").forward(req, resp);
                break;

            case "delete":  // xóa trực tiếp
                dao.delete(Integer.parseInt(req.getParameter("id")));
                resp.sendRedirect("HoadonServlet?action=list");
                break;

            default:  // list
                List<Hoadon> list = dao.getAll();
                req.setAttribute("list", list);
                req.getRequestDispatcher("hoadon/list.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req,
                          HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

            int id = req.getParameter("id") != null && !req.getParameter("id").isEmpty()
                    ? Integer.parseInt(req.getParameter("id"))
                    : 0;

            int customerId = Integer.parseInt(req.getParameter("customerId"));
            Date date = sdf.parse(req.getParameter("date"));
            double total = Double.parseDouble(req.getParameter("total"));
            String status = req.getParameter("status");

            Hoadon h = new Hoadon(id, customerId, date, total, status);

            if (id == 0) dao.insert(h);
            else dao.update(h);

        } catch (Exception e) {
            e.printStackTrace();
        }

        resp.sendRedirect("HoadonServlet?action=list");
    }
}
