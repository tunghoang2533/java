package controller;

import dao.SanphamDAO;
import dao.DanhmucDAO;
import model.Sanpham;
import model.Danhmuc;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/SanphamServlet")
public class SanphamServlet extends HttpServlet {

    private SanphamDAO sanphamDAO;
    private DanhmucDAO danhmucDAO;

    @Override
    public void init() {
        sanphamDAO = new SanphamDAO();
        danhmucDAO = new DanhmucDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "form":
                showForm(request, response);
                break;
            case "edit":
                editForm(request, response);
                break;
            case "delete":
                deleteProduct(request, response);
                break;
            default:
                listProducts(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");

        if ("insert".equals(action)) {
            insertProduct(request, response);
        } else if ("update".equals(action)) {
            updateProduct(request, response);
        }
    }

    // ====================== LIST ======================
    private void listProducts(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Sanpham> list = sanphamDAO.getAll();
        request.setAttribute("list", list);

        request.getRequestDispatcher("sanpham/list.jsp").forward(request, response);
    }

    // ====================== FORM ======================
    private void showForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // ⭐ Chỉ lấy danh mục đang hoạt động
        List<Danhmuc> danhMucs = danhmucDAO.getActive();
        request.setAttribute("danhmucs", danhMucs);

        request.setAttribute("product", null);
        request.getRequestDispatcher("sanpham/form.jsp").forward(request, response);
    }

    private void editForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        Sanpham p = sanphamDAO.getById(id);

        // ⭐ Chỉ lấy danh mục đang hoạt động
        List<Danhmuc> danhMucs = danhmucDAO.getActive();
        request.setAttribute("danhmucs", danhMucs);

        request.setAttribute("product", p);
        request.getRequestDispatcher("sanpham/edit.jsp").forward(request, response);
    }

    // ====================== CRUD ======================
    private void insertProduct(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        Sanpham p = getProductFromRequest(request);
        sanphamDAO.insert(p);

        response.sendRedirect("SanphamServlet?action=list");
    }

    private void updateProduct(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        Sanpham p = getProductFromRequest(request);
        p.setId(Integer.parseInt(request.getParameter("id")));

        sanphamDAO.update(p);
        response.sendRedirect("SanphamServlet?action=list");
    }

    private void deleteProduct(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        sanphamDAO.delete(id);

        response.sendRedirect("SanphamServlet?action=list");
    }

    // ====================== HELPER ======================
    private Sanpham getProductFromRequest(HttpServletRequest request) {

        String name = request.getParameter("name");
        int categoryId = Integer.parseInt(request.getParameter("category_id"));
        double price = Double.parseDouble(request.getParameter("price"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        String description = request.getParameter("description");
        String image = request.getParameter("image");
        int status = Integer.parseInt(request.getParameter("status"));

        Sanpham p = new Sanpham(0, name, categoryId, price, quantity);
        p.setDescription(description);
        p.setImage(image);
        p.setStatus(status);

        return p;
    }
}
