package controller;

import dao.DanhmucDAO;
import model.Danhmuc;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/DanhmucServlet")
public class DanhmucServlet extends HttpServlet {

    private DanhmucDAO danhmucDAO;

    @Override
    public void init() {
        danhmucDAO = new DanhmucDAO();
    }

    private Integer safeParseInt(String str) {
        try {
            return Integer.parseInt(str);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if (action == null) action = "list";

        switch (action) {

            case "form":
                request.getRequestDispatcher("/danhmuc/form.jsp").forward(request, response);
                break;

            case "edit":
                Integer idEdit = safeParseInt(request.getParameter("id"));
                if (idEdit == null) {
                    response.sendRedirect("DanhmucServlet?action=list");
                    return;
                }
                Danhmuc dmEdit = danhmucDAO.getById(idEdit);
                request.setAttribute("dm", dmEdit);
                request.getRequestDispatcher("/danhmuc/edit.jsp").forward(request, response);
                break;

            case "delete":
                Integer idDel = safeParseInt(request.getParameter("id"));
                if (idDel != null) {
                    danhmucDAO.delete(idDel);
                }
                response.sendRedirect("DanhmucServlet?action=list");
                break;

            default:
                List<Danhmuc> list = danhmucDAO.getAll();
                request.setAttribute("list", list);
                request.getRequestDispatcher("/danhmuc/list.jsp").forward(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");

        if ("save".equals(action)) {
            Danhmuc c = new Danhmuc();
            c.setName(request.getParameter("name"));
            c.setDescription(request.getParameter("description"));
            c.setStatus(Integer.parseInt(request.getParameter("status")));

            danhmucDAO.insert(c);
            response.sendRedirect("DanhmucServlet?action=list");

        } else if ("update".equals(action)) {
            Integer id = safeParseInt(request.getParameter("id"));
            if (id == null) {
                response.sendRedirect("DanhmucServlet?action=list");
                return;
            }

            Danhmuc c = new Danhmuc();
            c.setId(id);
            c.setName(request.getParameter("name"));
            c.setDescription(request.getParameter("description"));
            c.setStatus(Integer.parseInt(request.getParameter("status")));

            danhmucDAO.update(c);
            response.sendRedirect("DanhmucServlet?action=list");
        }
    }
}
