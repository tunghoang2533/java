package controller;

import dao.KhachhangDAO;
import model.Khachhang;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/KhachhangServlet")
public class KhachhangServlet extends HttpServlet {
    private KhachhangDAO dao;

    @Override
    public void init() throws ServletException {
        dao = new KhachhangDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "list":
                List<Khachhang> list = dao.getAll();
                request.setAttribute("khachhangs", list);
                request.getRequestDispatcher("/khachhang/list.jsp").forward(request, response);
                break;

            case "form":
                request.getRequestDispatcher("/khachhang/form.jsp").forward(request, response);
                break;

            case "edit":
                try {
                    int id = Integer.parseInt(request.getParameter("id"));
                    Khachhang kh = dao.getById(id);

                    if (kh == null) {
                        response.sendRedirect(request.getContextPath() + "/KhachhangServlet?action=list");
                        return;
                    }

                    request.setAttribute("kh", kh);
                    request.getRequestDispatcher("/khachhang/edit.jsp").forward(request, response);

                } catch (NumberFormatException e) {
                    response.sendRedirect(request.getContextPath() + "/KhachhangServlet?action=list");
                }
                break;

            case "delete":
                try {
                    int did = Integer.parseInt(request.getParameter("id"));
                    dao.delete(did);
                } catch (Exception ignored) {}

                response.sendRedirect(request.getContextPath() + "/KhachhangServlet?action=list");
                break;

            default:
                response.sendRedirect(request.getContextPath() + "/KhachhangServlet?action=list");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String idStr = request.getParameter("id");
        String name = request.getParameter("name");
        String phone = request.getParameter("phone");
        String email = request.getParameter("email");
        String address = request.getParameter("address");
        int status = request.getParameter("status") != null ? 1 : 0;

        Khachhang kh = new Khachhang();
        kh.setName(name);
        kh.setPhone(phone);
        kh.setEmail(email);
        kh.setAddress(address);
        kh.setStatus(status);

        // Insert
        if (idStr == null || idStr.isEmpty()) {
            dao.insert(kh);
        }
        // Update
        else {
            try {
                int id = Integer.parseInt(idStr);
                kh.setId(id);
                dao.update(kh);
            } catch (Exception ignored) {}
        }

        // Redirect đúng context-path → KHÔNG BAO GIỜ lỗi 404 nữa
        response.sendRedirect(request.getContextPath() + "/KhachhangServlet?action=list");
    }
}
