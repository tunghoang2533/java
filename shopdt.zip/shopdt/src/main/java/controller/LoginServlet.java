package controller;

import dao.AccountDAO;
import model.Account;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private AccountDAO dao;

    @Override
    public void init() throws ServletException {
        dao = new AccountDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        
        // Xử lý đăng xuất
        if ("logout".equals(action)) {
            HttpSession session = request.getSession(false);
            if (session != null) session.invalidate();
            response.sendRedirect("login.jsp?msg=logout_success");
            return;
        }

        // Nếu đã đăng nhập rồi thì chuyển đến đúng trang theo role
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("account") != null) {
            String role = (String) session.getAttribute("role");
            if ("admin".equals(role)) {
                response.sendRedirect("index.jsp");
            } else {
                response.sendRedirect("user_index.jsp");
            }
            return;
        }

        request.getRequestDispatcher("login.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Kiểm tra nhập thiếu
        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
            request.setAttribute("error", "Vui lòng nhập đủ thông tin!");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }

        // Kiểm tra tài khoản
        Account acc = dao.login(username, password);
        if (acc == null) {
            request.setAttribute("error", "Sai tài khoản hoặc mật khẩu!");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }

        // Lưu session
        HttpSession session = request.getSession();
        session.setAttribute("account", acc);
        session.setAttribute("role", acc.getRole());
        session.setMaxInactiveInterval(30 * 60);

        // Chuyển trang theo role
        if ("admin".equals(acc.getRole())) {
            response.sendRedirect("index.jsp");
        } else {
            response.sendRedirect("user_index.jsp");
        }
    }
}
