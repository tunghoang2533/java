package model;

import java.util.Date;

public class Hoadon {
    private int id;
    private int customerId;
    private Date date;
    private double total;
    private String status;

    public Hoadon() {}

    public Hoadon(int id, int customerId, Date date, double total, String status) {
        this.id = id;
        this.customerId = customerId;
        this.date = date;
        this.total = total;
        this.status = status;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getCustomerId() { return customerId; }
    public void setCustomerId(int customerId) { this.customerId = customerId; }

    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }

    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
