package db_connect;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnect {

    // Cổng phpMyAdmin của bạn là 8082 → nhưng MySQL KHÔNG phụ thuộc phpMyadmin
    // MySQL mặc định chạy port 3306 → vẫn để 3306
    private static final String URL = 
        "jdbc:mysql://localhost:3306/shopdb?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";

    private static final String USER = "root";
    private static final String PASS = "23122005"; // đổi theo mật khẩu MySQL của bạn

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // ⭐ KHÔNG ĐƯỢC ĐỂ TRỐNG
            System.out.println("MySQL Driver Loaded Successfully");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws Exception {
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
