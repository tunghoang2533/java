package dao;

import db_connect.DBConnect;
import model.Hoadon;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HoadonDAO {

    private Connection conn;

    public HoadonDAO() {
        try {
            conn = DBConnect.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Hoadon> getAll() {
        List<Hoadon> list = new ArrayList<>();
        String sql = "SELECT * FROM hoadon";

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Hoadon h = new Hoadon(
                        rs.getInt("id"),
                        rs.getInt("customerId"),
                        rs.getDate("date"),
                        rs.getDouble("total"),
                        rs.getString("status")
                );
                list.add(h);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public Hoadon getById(int id) {
        String sql = "SELECT * FROM hoadon WHERE id = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Hoadon(
                        rs.getInt("id"),
                        rs.getInt("customerId"),
                        rs.getDate("date"),
                        rs.getDouble("total"),
                        rs.getString("status")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public boolean insert(Hoadon h) {
        String sql = "INSERT INTO hoadon(customerId, date, total, status) VALUES (?, ?, ?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, h.getCustomerId());
            ps.setDate(2, new java.sql.Date(h.getDate().getTime()));
            ps.setDouble(3, h.getTotal());
            ps.setString(4, h.getStatus());

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean update(Hoadon h) {
        String sql = "UPDATE hoadon SET customerId=?, date=?, total=?, status=? WHERE id=?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, h.getCustomerId());
            ps.setDate(2, new java.sql.Date(h.getDate().getTime()));
            ps.setDouble(3, h.getTotal());
            ps.setString(4, h.getStatus());
            ps.setInt(5, h.getId());

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean delete(int id) {
        String sql = "DELETE FROM hoadon WHERE id=?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}
