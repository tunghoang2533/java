package dao;

import model.Sanpham;
import db_connect.DBConnect;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SanphamDAO {
    public List<Sanpham> getAll(){
        List<Sanpham> list = new ArrayList<>();
        String sql = "SELECT * FROM Sanpham ORDER BY id";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps=conn.prepareStatement(sql); ResultSet rs=ps.executeQuery()){
            while(rs.next()){
                Sanpham p = new Sanpham(rs.getInt("id"), rs.getString("name"), rs.getInt("category_id"), rs.getDouble("price"), rs.getInt("quantity"));
                p.setDescription(rs.getString("description")); p.setImage(rs.getString("image")); p.setStatus(rs.getInt("status"));
                list.add(p);
            }
        } catch(Exception e){e.printStackTrace();}
        return list;
    }

    public Sanpham getById(int id){
        String sql="SELECT * FROM Sanpham WHERE id=?";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps=conn.prepareStatement(sql)){
            ps.setInt(1,id);
            try (ResultSet rs = ps.executeQuery()){
                if (rs.next()){
                    Sanpham p = new Sanpham(rs.getInt("id"), rs.getString("name"), rs.getInt("category_id"), rs.getDouble("price"), rs.getInt("quantity"));
                    p.setDescription(rs.getString("description")); p.setImage(rs.getString("image")); p.setStatus(rs.getInt("status"));
                    return p;
                }
            }
        } catch(Exception e){e.printStackTrace();}
        return null;
    }

    public boolean insert(Sanpham p){
        String sql="INSERT INTO Sanpham(name,category_id,price,quantity,description,image,status) VALUES(?,?,?,?,?,?,?)";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps=conn.prepareStatement(sql)){
            ps.setString(1,p.getName()); ps.setInt(2,p.getCategoryId()); ps.setDouble(3,p.getPrice()); ps.setInt(4,p.getQuantity());
            ps.setString(5,p.getDescription()); ps.setString(6,p.getImage()); ps.setInt(7,p.getStatus());
            return ps.executeUpdate()>0;
        } catch(Exception e){e.printStackTrace();}
        return false;
    }

    public boolean update(Sanpham p){
        String sql="UPDATE Sanpham SET name=?,category_id=?,price=?,quantity=?,description=?,image=?,status=? WHERE id=?";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps=conn.prepareStatement(sql)){
            ps.setString(1,p.getName()); ps.setInt(2,p.getCategoryId()); ps.setDouble(3,p.getPrice()); ps.setInt(4,p.getQuantity());
            ps.setString(5,p.getDescription()); ps.setString(6,p.getImage()); ps.setInt(7,p.getStatus()); ps.setInt(8,p.getId());
            return ps.executeUpdate()>0;
        } catch(Exception e){e.printStackTrace();}
        return false;
    }

    public boolean delete(int id){
        String sql="DELETE FROM Sanpham WHERE id=?";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps=conn.prepareStatement(sql)){
            ps.setInt(1,id); return ps.executeUpdate()>0;
        } catch(Exception e){e.printStackTrace();}
        return false;
    }
}
