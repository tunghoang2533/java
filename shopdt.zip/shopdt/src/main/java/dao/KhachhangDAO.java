package dao;

import model.Khachhang;
import db_connect.DBConnect;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class KhachhangDAO {

    // Lấy danh sách khách hàng
    public List<Khachhang> getAll() {
        List<Khachhang> list = new ArrayList<>();
        String sql = "SELECT * FROM Khachhang ORDER BY id DESC";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Khachhang c = new Khachhang(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("phone"),
                        rs.getString("email"),
                        rs.getString("address")
                );
                c.setStatus(rs.getInt("status"));
                c.setCreatedAt(rs.getTimestamp("created_at"));   // <<< NEW
                list.add(c);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Lấy theo ID
    public Khachhang getById(int id) {
        String sql = "SELECT * FROM Khachhang WHERE id = ?";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    Khachhang c = new Khachhang(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getString("phone"),
                            rs.getString("email"),
                            rs.getString("address")
                    );
                    c.setStatus(rs.getInt("status"));
                    c.setCreatedAt(rs.getTimestamp("created_at")); // <<< NEW
                    return c;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // Thêm mới
    public boolean insert(Khachhang c) {
        String sql = "INSERT INTO Khachhang(name, phone, email, address, status) VALUES(?,?,?,?,?)";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, c.getName());
            ps.setString(2, c.getPhone());
            ps.setString(3, c.getEmail());
            ps.setString(4, c.getAddress());
            ps.setInt(5, c.getStatus());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    // Cập nhật
    public boolean update(Khachhang c) {
        String sql = "UPDATE Khachhang SET name=?, phone=?, email=?, address=?, status=? WHERE id=?";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, c.getName());
            ps.setString(2, c.getPhone());
            ps.setString(3, c.getEmail());
            ps.setString(4, c.getAddress());
            ps.setInt(5, c.getStatus());
            ps.setInt(6, c.getId());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    // Xóa
    public boolean delete(int id) {
        String sql = "DELETE FROM Khachhang WHERE id=?";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}
