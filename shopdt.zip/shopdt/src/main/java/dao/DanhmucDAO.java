package dao;

import model.Danhmuc;
import db_connect.DBConnect;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DanhmucDAO {

    // ===================== LẤY TẤT CẢ DANH MỤC =====================
    public List<Danhmuc> getAll() {
        List<Danhmuc> list = new ArrayList<>();
        String sql = "SELECT * FROM Danhmuc ORDER BY id";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Danhmuc c = new Danhmuc(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("description")
                );
                c.setStatus(rs.getInt("status"));
                list.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // ===================== LẤY DANH MỤC HOẠT ĐỘNG (status = 1) =====================
    public List<Danhmuc> getActive() {
        List<Danhmuc> list = new ArrayList<>();
        String sql = "SELECT * FROM Danhmuc WHERE status = 1 ORDER BY id";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Danhmuc c = new Danhmuc(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("description")
                );
                c.setStatus(rs.getInt("status"));
                list.add(c);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // ===================== GET BY ID =====================
    public Danhmuc getById(int id) {
        String sql = "SELECT * FROM Danhmuc WHERE id=?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Danhmuc c = new Danhmuc(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getString("description")
                    );
                    c.setStatus(rs.getInt("status"));
                    return c;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // ===================== INSERT =====================
    public boolean insert(Danhmuc c) {
        String sql = "INSERT INTO Danhmuc(name,description,status) VALUES(?,?,?)";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, c.getName());
            ps.setString(2, c.getDescription());
            ps.setInt(3, c.getStatus());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // ===================== UPDATE =====================
    public boolean update(Danhmuc c) {
        String sql = "UPDATE Danhmuc SET name=?,description=?,status=? WHERE id=?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, c.getName());
            ps.setString(2, c.getDescription());
            ps.setInt(3, c.getStatus());
            ps.setInt(4, c.getId());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // ===================== DELETE =====================
    public boolean delete(int id) {
        String sql = "DELETE FROM Danhmuc WHERE id=?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
