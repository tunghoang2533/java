package dao;

import model.Account;
import db_connect.DBConnect;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AccountDAO {

    public Account login(String username, String password) {
        String sql = "SELECT * FROM accounts WHERE username=? AND password=? AND status=1";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Account a = new Account();
                    a.setId(rs.getInt("id"));
                    a.setUsername(rs.getString("username"));
                    a.setPassword(rs.getString("password"));
                    a.setFullname(rs.getString("fullname"));
                    a.setRole(rs.getString("role"));
                    a.setStatus(rs.getInt("status"));
                    return a;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    public List<Account> getAll() {
        List<Account> list = new ArrayList<>();
        String sql = "SELECT * FROM accounts ORDER BY id";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Account a = new Account();
                a.setId(rs.getInt("id"));
                a.setUsername(rs.getString("username"));
                a.setFullname(rs.getString("fullname"));
                a.setRole(rs.getString("role"));
                a.setStatus(rs.getInt("status"));
                list.add(a);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }


    // ⭐⭐⭐ THÊM HÀM BỊ THIẾU — HÀM NÀY LÀM ACCOUNT SERVLET KHÔNG LỖI
    public Account getById(int id) {
        String sql = "SELECT * FROM accounts WHERE id=?";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Account a = new Account();
                    a.setId(rs.getInt("id"));
                    a.setUsername(rs.getString("username"));
                    a.setPassword(rs.getString("password"));
                    a.setFullname(rs.getString("fullname"));
                    a.setRole(rs.getString("role"));
                    a.setStatus(rs.getInt("status"));
                    return a;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }



    public boolean insert(Account a) {
        String sql = "INSERT INTO accounts(username,password,fullname,role,status) VALUES(?,?,?,?,?)";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, a.getUsername());
            ps.setString(2, a.getPassword());
            ps.setString(3, a.getFullname());
            ps.setString(4, a.getRole());
            ps.setInt(5, a.getStatus());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }


    public boolean update(Account a) {
        String sql = "UPDATE accounts SET username=?,password=?,fullname=?,role=?,status=? WHERE id=?";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, a.getUsername());
            ps.setString(2, a.getPassword());
            ps.setString(3, a.getFullname());
            ps.setString(4, a.getRole());
            ps.setInt(5, a.getStatus());
            ps.setInt(6, a.getId());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }


    public boolean delete(int id) {
        String sql = "DELETE FROM accounts WHERE id=?";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}
